Nexus IT Support Ticket System UI

A clean, responsive, fully-componentized "IT Support Ticket System UI" built strictly with "HTML5 and CSS3" (No JavaScript, No Frameworks).

Features Built

1.Header & Navigation: Sticky navigation bar complete with company identity and structural internal routing links.
2.Dashboard Summary Cards: A flexible grid layout showcasing total tickets categorized by status (Open, In Progress, Resolved).
3.Raise a Ticket Form: A comprehensive two-column grid form equipped with semantic inputs, custom hover/focus states, and accessibility attributes.
4.Ticket List Table: A fully responsive data table displaying 6 distinct tickets with colored status pills and ticket identifiers.
5.Bonus - Ticket Details View: Dedicated component container mapping deep tracking points (`Ticket → User → Issue → Priority → Status → Resolution`).
6.Print Optimization (`@media print`): Clean, printer-friendly structural layout that strips navigational chrome and shadows when saved to PDF or paper.

CSS Techniques & Patterns Practiced
CSS Custom Properties (Variables) for consistent design tokens (colors, radii, shadows).
CSS Flexbox & Grid for structural layouts and component alignment.
Form Controls Styling with custom focus states and seamless accessibility.
Responsive Web Design using modern media queries and flexible sizing units (`rem`, `fr`).